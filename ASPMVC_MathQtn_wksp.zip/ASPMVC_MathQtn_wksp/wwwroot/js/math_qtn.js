﻿window.onload = function () {
    let x_elem = document.getElementById("x");
    let y_elem = document.getElementById("y");
    let z_elem = document.getElementById("z");
    let msg_elem = document.getElementById("msg");
    let z_val, y_val;

    get_qtn();

    x.addEventListener("keypress", function(event) {
        if (event.keycode === 13 || event.key === "Enter") {   //检测是否为enter键，enter的键码为13，===表示严格相等（例如==可以将char转换为int和数字比较，但是===不行）
            //if (CheckValidNum(x_elem.value)) {
            let x_val = parseInt(x_elem.value);
                if (x_val + y_val === z_val) {
                    msg_elem.innerHTML = "Correct! Fetching new question...";
                    msg_elem.classList.remove("incorrect");
                    msg_elem.classList.add("correct");
                    setTimeout(function () {
                        x_elem.value = "";
                        msg_elem.innerHTML = "";
                        get_qtn();
                    }, 2000);
                }
                else {
                    msg_elem.innerHTML = "Incorrect! Try again.";
                    msg_elem.classList.remove("correct");
                    msg_elem.classList.add("incorrect");
                }
            //}
        }
    });

    function get_qtn(){
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "/Math/RandomGene");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let qtn = JSON.parse(xhr.responseText);
                y_val = parseInt(qtn.y);
                z_val = parseInt(qtn.z);

                y_elem.innerHTML = y_val;
                z_elem.innerHTML = z_val;
            }
        }
        xhr.send();
    }

    function PressEnter(event) {
        if (event.Keycode === 13 || event.Key === "Enter"){   //检测是否为enter键，enter的键码为13，===表示严格相等（例如==可以将char转换为int和数字比较，但是===不行）
            if (CheckValidNum(x_elem.value)) {
                let x_val = parseInt(x_elem.value);
                if (x_val + y_val == z_val) {
                    msg_elem.innerHTML = "Correct! Fetching new question...";
                    setTimeout(function () {
                        x_elem.value = "";
                        msg_elem.innerHTML = "";
                        get_qtn;
                    }, 2000);
                }
                else {
                    msg_elem.innerHTML = "Incorrect! Try again.";
                }
            }
        }
    }
/*if (CheckValidNum(input_elem.value)) {
                let sentval = new XMLHttpRequest();
                sentval.open("POST", "/Math/Check");
                //sentval.setRequestHeader("Content-Type","applicaiton/json; charset=utf8");
                sentval.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                //let data = {"Adder":input_elem.value};
                //sentval.send(JSON.stringify(data));
                sentval.send("input=" + input_elem.value);
            }*/
    function CheckValidNum(input) {
        if (isNaN(input)) {
            alert("Please enter a valid number!");
            return false;
        }
        const pattern = /^\d+$/;
        if (!pattern.test(input)) {
            alert("Please enter a valid number!");
            return false;
        }
        return true;
    }

    /*function answerstatus(flag) {
        if (flag) {
            msg_elem.innerHTML = "Correct! Fetching new question...";
        }
        else {
            msg_elem.innerHTML = "Incorrect! Try again.";
        }
    }*/
}