﻿using Microsoft.AspNetCore.Mvc;
using System.CodeDom.Compiler;

namespace ASPMVC_MathQtn_wksp.Controllers
{
    public class MathController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult RandomGene()
        {
            Random rnd = new Random();
            int a = rnd.Next(0, 99);
            int b = rnd.Next(0, 99);
            int y = (a > b) ? b : a;
            int z = (a > b) ? a : b;
            return Json(new { y = y, z = z });
        }
        
        /*public IActionResult Check(int input)
        {
            if (input == adder)
            {
                ViewBag.Msg = "Correct! Fetching new question...";
                ViewBag.Color = "green";
                RandomGene();
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Msg = "Incorrect! Try again!";
                ViewBag.Color = "red";
                return RedirectToAction("Index");
            }
        }*/
    }
}
